#pragma once
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 10;