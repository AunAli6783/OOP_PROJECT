#include <iostream>
#include "managementsystem.h"
using namespace std;

int main()
{	
	managementsystem m;
	m.run();

	return 0;
}